const preset = require('./lib').default;

module.exports = preset;
