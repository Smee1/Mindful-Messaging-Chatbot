export * from './types';
declare const _default: {
    globalSetup: string;
    globalTeardown: string;
    testEnvironment: string;
};
export default _default;
