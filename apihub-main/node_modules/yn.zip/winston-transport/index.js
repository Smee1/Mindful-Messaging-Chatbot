'use strict';

// Expose modern transport directly as the export
module.exports = require('./modern');

// Expose legacy stream
module.exports.LegacyTransportStream = require('./legacy');
