export function install(opts?: {
    cacheDir?: string;
    prefix?: string;
}): {
    uninstall(): void;
} | undefined;
x