<!-- *Before creating an issue please make sure you are using the latest version of mquery -->

**Do you want to request a *feature* or report a *bug*?**

**What is the current behavior?**

**If the current behavior is a bug, please provide the steps to reproduce.**

**What is the expected behavior?**

**What are the versions of Node.js and mquery are you are using? Note that "latest" is not a version.**
