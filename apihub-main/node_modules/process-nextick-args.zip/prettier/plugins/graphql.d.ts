import { Parser } from "../index.js";

export declare const parsers: {
  graphql: Parser;
};
