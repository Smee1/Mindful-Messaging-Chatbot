import { Parser } from "../index.js";

export declare const parsers: {
  meriyah: Parser;
};
