import { Parser } from "../index.js";

export declare const parsers: {
  yaml: Parser;
};
