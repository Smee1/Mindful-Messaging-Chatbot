import { Parser } from "../index.js";

export declare const parsers: {
  __ng_action: Parser;
  __ng_binding: Parser;
  __ng_directive: Parser;
  __ng_interpolation: Parser;
};
