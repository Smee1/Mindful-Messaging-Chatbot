import { Parser } from "../index.js";

export declare const parsers: {
  css: Parser;
  less: Parser;
  scss: Parser;
};
