import { Parser } from "../index.js";

export declare const parsers: {
  markdown: Parser;
  mdx: Parser;
  remark: Parser;
};
