import { Parser } from "../index.js";

export declare const parsers: {
  typescript: Parser;
};
