var convert = require('./convert'),
    func = convert('camelCase', require('../camelCase'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
