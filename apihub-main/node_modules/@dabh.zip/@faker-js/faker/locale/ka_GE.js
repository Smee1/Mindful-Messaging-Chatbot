module.exports = require('../dist/cjs/locale/ka_GE');
