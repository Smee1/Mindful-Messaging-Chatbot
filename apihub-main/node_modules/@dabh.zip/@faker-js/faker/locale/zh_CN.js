module.exports = require('../dist/cjs/locale/zh_CN');
