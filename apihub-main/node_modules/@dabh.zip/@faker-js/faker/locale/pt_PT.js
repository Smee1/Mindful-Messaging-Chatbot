module.exports = require('../dist/cjs/locale/pt_PT');
