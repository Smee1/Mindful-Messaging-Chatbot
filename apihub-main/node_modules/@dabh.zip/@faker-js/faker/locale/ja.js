module.exports = require('../dist/cjs/locale/ja');
