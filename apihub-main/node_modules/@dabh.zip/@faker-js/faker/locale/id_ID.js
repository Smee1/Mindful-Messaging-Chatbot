module.exports = require('../dist/cjs/locale/id_ID');
