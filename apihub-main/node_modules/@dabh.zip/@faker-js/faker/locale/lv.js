module.exports = require('../dist/cjs/locale/lv');
