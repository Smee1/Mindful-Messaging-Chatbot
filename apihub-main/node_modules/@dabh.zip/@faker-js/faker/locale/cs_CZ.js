module.exports = require('../dist/cjs/locale/cs_CZ');
