module.exports = require('../dist/cjs/locale/sr_RS_latin');
