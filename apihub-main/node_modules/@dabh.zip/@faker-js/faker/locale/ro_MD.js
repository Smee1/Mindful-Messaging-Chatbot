module.exports = require('../dist/cjs/locale/ro_MD');
