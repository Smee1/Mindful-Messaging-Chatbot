module.exports = require('../dist/cjs/locale/de_AT');
