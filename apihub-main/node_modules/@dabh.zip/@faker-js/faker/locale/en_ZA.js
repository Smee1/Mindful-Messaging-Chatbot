module.exports = require('../dist/cjs/locale/en_ZA');
