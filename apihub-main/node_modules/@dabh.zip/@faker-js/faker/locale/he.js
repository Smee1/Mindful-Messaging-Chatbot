module.exports = require('../dist/cjs/locale/he');
