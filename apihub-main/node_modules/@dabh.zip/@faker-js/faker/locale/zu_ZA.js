module.exports = require('../dist/cjs/locale/zu_ZA');
