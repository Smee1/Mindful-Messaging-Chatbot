module.exports = require('../dist/cjs/locale/nb_NO');
