module.exports = require('../dist/cjs/locale/fa');
