module.exports = require('../dist/cjs/locale/tr');
