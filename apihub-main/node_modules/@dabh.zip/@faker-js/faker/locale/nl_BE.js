module.exports = require('../dist/cjs/locale/nl_BE');
