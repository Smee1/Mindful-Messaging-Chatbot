module.exports = require('../dist/cjs/locale/el');
