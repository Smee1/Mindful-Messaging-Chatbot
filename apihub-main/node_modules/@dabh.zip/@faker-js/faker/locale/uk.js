module.exports = require('../dist/cjs/locale/uk');
