module.exports = require('../dist/cjs/locale/en_AU_ocker');
