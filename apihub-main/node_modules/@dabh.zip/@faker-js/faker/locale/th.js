module.exports = require('../dist/cjs/locale/th');
