export declare function getEditCommit(cwd?: string, edit?: boolean | string): Promise<string[]>;
//# sourceMappingURL=get-edit-commit.d.ts.map