import gitRawCommits from 'git-raw-commits';
export declare function getHistoryCommits(options: gitRawCommits.GitOptions, opts?: {
    cwd?: string;
}): Promise<string[]>;
//# sourceMappingURL=get-history-commits.d.ts.map