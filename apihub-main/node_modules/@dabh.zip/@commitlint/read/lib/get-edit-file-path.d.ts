export declare function getEditFilePath(top: string, edit?: boolean | string): Promise<string>;
//# sourceMappingURL=get-edit-file-path.d.ts.map