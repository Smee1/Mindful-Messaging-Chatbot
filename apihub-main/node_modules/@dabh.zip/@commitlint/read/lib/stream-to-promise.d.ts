/// <reference types="node" />
import { Readable } from 'stream';
export declare function streamToPromise(stream: Readable): Promise<string[]>;
//# sourceMappingURL=stream-to-promise.d.ts.map