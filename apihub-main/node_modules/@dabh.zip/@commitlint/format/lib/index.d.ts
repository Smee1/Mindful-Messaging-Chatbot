export { default } from './format';
export * from './format';
//# sourceMappingURL=index.d.ts.map