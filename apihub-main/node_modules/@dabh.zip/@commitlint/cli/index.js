const path = require('path');

module.exports = path.join(__dirname, 'cli.js');
