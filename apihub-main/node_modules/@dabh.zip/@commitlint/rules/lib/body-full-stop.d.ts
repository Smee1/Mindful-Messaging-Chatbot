import { SyncRule } from '@commitlint/types';
export declare const bodyFullStop: SyncRule<string>;
//# sourceMappingURL=body-full-stop.d.ts.map