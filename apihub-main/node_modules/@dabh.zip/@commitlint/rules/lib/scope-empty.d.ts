import { SyncRule } from '@commitlint/types';
export declare const scopeEmpty: SyncRule;
//# sourceMappingURL=scope-empty.d.ts.map