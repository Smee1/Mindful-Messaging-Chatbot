import { SyncRule } from '@commitlint/types';
export declare const subjectFullStop: SyncRule<string>;
//# sourceMappingURL=subject-full-stop.d.ts.map