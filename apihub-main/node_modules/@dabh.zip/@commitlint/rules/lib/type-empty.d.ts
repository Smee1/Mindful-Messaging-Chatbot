import { SyncRule } from '@commitlint/types';
export declare const typeEmpty: SyncRule;
//# sourceMappingURL=type-empty.d.ts.map