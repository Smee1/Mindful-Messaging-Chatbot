import { SyncRule } from '@commitlint/types';
export declare const footerMinLength: SyncRule<number>;
//# sourceMappingURL=footer-min-length.d.ts.map