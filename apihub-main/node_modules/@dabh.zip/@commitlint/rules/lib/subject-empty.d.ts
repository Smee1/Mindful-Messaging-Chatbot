import { SyncRule } from '@commitlint/types';
export declare const subjectEmpty: SyncRule;
//# sourceMappingURL=subject-empty.d.ts.map