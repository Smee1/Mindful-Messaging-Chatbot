import { SyncRule } from '@commitlint/types';
export declare const trailerExists: SyncRule<string>;
//# sourceMappingURL=trailer-exists.d.ts.map