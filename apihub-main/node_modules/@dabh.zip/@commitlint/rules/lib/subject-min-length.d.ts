import { SyncRule } from '@commitlint/types';
export declare const subjectMinLength: SyncRule<number>;
//# sourceMappingURL=subject-min-length.d.ts.map