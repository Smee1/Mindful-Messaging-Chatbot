import { SyncRule } from '@commitlint/types';
export declare const headerFullStop: SyncRule<string>;
//# sourceMappingURL=header-full-stop.d.ts.map