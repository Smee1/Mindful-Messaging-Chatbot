import { SyncRule } from '@commitlint/types';
export declare const footerMaxLineLength: SyncRule<number>;
//# sourceMappingURL=footer-max-line-length.d.ts.map