import { TargetCaseType, SyncRule } from '@commitlint/types';
export declare const typeCase: SyncRule<TargetCaseType | TargetCaseType[]>;
//# sourceMappingURL=type-case.d.ts.map