import { SyncRule } from '@commitlint/types';
export declare const bodyMaxLineLength: SyncRule<number>;
//# sourceMappingURL=body-max-line-length.d.ts.map