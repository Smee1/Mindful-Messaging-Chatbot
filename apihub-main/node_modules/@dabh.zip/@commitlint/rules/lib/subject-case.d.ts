import { TargetCaseType, SyncRule } from '@commitlint/types';
export declare const subjectCase: SyncRule<TargetCaseType | TargetCaseType[]>;
//# sourceMappingURL=subject-case.d.ts.map