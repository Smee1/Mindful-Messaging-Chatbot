import { SyncRule } from '@commitlint/types';
export declare const footerMaxLength: SyncRule<number>;
//# sourceMappingURL=footer-max-length.d.ts.map