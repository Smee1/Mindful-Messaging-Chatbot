import { SyncRule } from '@commitlint/types';
export declare const bodyEmpty: SyncRule;
//# sourceMappingURL=body-empty.d.ts.map