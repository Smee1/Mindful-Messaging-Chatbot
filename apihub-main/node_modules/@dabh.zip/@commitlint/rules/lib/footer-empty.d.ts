import { SyncRule } from '@commitlint/types';
export declare const footerEmpty: SyncRule;
//# sourceMappingURL=footer-empty.d.ts.map