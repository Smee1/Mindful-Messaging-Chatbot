import { SyncRule } from '@commitlint/types';
export declare const scopeMaxLength: SyncRule<number>;
//# sourceMappingURL=scope-max-length.d.ts.map