import { SyncRule } from '@commitlint/types';
export declare const typeMinLength: SyncRule<number>;
//# sourceMappingURL=type-min-length.d.ts.map