import { SyncRule } from '@commitlint/types';
export declare const referencesEmpty: SyncRule;
//# sourceMappingURL=references-empty.d.ts.map