import { SyncRule } from '@commitlint/types';
export declare const bodyLeadingBlank: SyncRule;
//# sourceMappingURL=body-leading-blank.d.ts.map