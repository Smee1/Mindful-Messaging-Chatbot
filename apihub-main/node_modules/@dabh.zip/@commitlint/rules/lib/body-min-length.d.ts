import { SyncRule } from '@commitlint/types';
export declare const bodyMinLength: SyncRule<number>;
//# sourceMappingURL=body-min-length.d.ts.map