import { SyncRule } from '@commitlint/types';
export declare const subjectExclamationMark: SyncRule;
//# sourceMappingURL=subject-exclamation-mark.d.ts.map