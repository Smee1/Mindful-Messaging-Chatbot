import { TargetCaseType, SyncRule } from '@commitlint/types';
export declare const scopeCase: SyncRule<TargetCaseType | TargetCaseType[]>;
//# sourceMappingURL=scope-case.d.ts.map