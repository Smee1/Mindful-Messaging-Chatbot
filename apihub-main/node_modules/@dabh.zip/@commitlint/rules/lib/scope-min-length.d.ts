import { SyncRule } from '@commitlint/types';
export declare const scopeMinLength: SyncRule<number>;
//# sourceMappingURL=scope-min-length.d.ts.map