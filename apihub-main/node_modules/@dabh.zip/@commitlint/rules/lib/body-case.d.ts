import { TargetCaseType, SyncRule } from '@commitlint/types';
export declare const bodyCase: SyncRule<TargetCaseType | TargetCaseType[]>;
//# sourceMappingURL=body-case.d.ts.map