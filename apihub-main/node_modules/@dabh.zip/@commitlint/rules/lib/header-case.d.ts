import { TargetCaseType, SyncRule } from '@commitlint/types';
export declare const headerCase: SyncRule<TargetCaseType | TargetCaseType[]>;
//# sourceMappingURL=header-case.d.ts.map