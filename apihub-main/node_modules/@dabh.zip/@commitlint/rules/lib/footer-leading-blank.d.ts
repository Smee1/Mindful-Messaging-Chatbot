import { SyncRule } from '@commitlint/types';
export declare const footerLeadingBlank: SyncRule;
//# sourceMappingURL=footer-leading-blank.d.ts.map