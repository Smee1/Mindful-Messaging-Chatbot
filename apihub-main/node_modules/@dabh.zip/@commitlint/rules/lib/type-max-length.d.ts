import { SyncRule } from '@commitlint/types';
export declare const typeMaxLength: SyncRule<number>;
//# sourceMappingURL=type-max-length.d.ts.map