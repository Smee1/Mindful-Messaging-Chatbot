import { SyncRule } from '@commitlint/types';
export declare const bodyMaxLength: SyncRule<number>;
//# sourceMappingURL=body-max-length.d.ts.map