import { SyncRule } from '@commitlint/types';
export declare const headerMaxLength: SyncRule<number>;
//# sourceMappingURL=header-max-length.d.ts.map