import { SyncRule } from '@commitlint/types';
export declare const headerMinLength: SyncRule<number>;
//# sourceMappingURL=header-min-length.d.ts.map