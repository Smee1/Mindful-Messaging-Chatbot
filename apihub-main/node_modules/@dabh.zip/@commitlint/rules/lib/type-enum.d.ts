import { SyncRule } from '@commitlint/types';
export declare const typeEnum: SyncRule<string[]>;
//# sourceMappingURL=type-enum.d.ts.map