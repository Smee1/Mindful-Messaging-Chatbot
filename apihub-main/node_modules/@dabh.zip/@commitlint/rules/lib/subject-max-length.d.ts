import { SyncRule } from '@commitlint/types';
export declare const subjectMaxLength: SyncRule<number>;
//# sourceMappingURL=subject-max-length.d.ts.map