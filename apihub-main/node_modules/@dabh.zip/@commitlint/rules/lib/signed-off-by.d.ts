import { SyncRule } from '@commitlint/types';
export declare const signedOffBy: SyncRule<string>;
//# sourceMappingURL=signed-off-by.d.ts.map