import { SyncRule } from '@commitlint/types';
export declare const scopeEnum: SyncRule<string[]>;
//# sourceMappingURL=scope-enum.d.ts.map