import { LintOptions, LintOutcome, QualifiedRules } from '@commitlint/types';
export default function lint(message: string, rawRulesConfig?: QualifiedRules, rawOpts?: LintOptions): Promise<LintOutcome>;
//# sourceMappingURL=lint.d.ts.map