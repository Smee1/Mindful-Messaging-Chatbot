export default message;
declare function message(input?: (string | null | undefined)[]): string;
//# sourceMappingURL=index.d.ts.map