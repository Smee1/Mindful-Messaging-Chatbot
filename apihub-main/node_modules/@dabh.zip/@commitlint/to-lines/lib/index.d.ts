export default function toLines(input: string): string[];
//# sourceMappingURL=index.d.ts.map