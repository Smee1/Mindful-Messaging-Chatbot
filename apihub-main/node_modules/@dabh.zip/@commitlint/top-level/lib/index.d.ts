export default toplevel;
/**
 * Find the next git root
 */
declare function toplevel(cwd?: string): Promise<string | undefined>;
//# sourceMappingURL=index.d.ts.map