import { UserConfig } from '@commitlint/types';
export declare function validateConfig(source: string, config: unknown): asserts config is UserConfig;
//# sourceMappingURL=validate.d.ts.map