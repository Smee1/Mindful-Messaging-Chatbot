declare const _default: (value: string, max: number) => boolean;
export default _default;
//# sourceMappingURL=max-line-length.d.ts.map