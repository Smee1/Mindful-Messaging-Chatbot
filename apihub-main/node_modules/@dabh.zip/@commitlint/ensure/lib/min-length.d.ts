declare const _default: (value: string, min: number) => boolean;
export default _default;
//# sourceMappingURL=min-length.d.ts.map