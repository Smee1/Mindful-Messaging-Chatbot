declare const _default: (value: string) => boolean;
export default _default;
//# sourceMappingURL=not-empty.d.ts.map