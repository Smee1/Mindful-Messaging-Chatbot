declare const _default: (value: any, enums?: any[]) => boolean;
export default _default;
//# sourceMappingURL=enum.d.ts.map