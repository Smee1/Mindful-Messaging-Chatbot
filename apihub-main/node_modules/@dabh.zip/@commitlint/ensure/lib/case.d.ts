import { TargetCaseType } from '@commitlint/types';
export default ensureCase;
declare function ensureCase(raw?: string, target?: TargetCaseType): boolean;
//# sourceMappingURL=case.d.ts.map