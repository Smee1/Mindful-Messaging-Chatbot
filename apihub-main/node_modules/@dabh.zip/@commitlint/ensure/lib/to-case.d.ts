import { TargetCaseType } from '@commitlint/types';
export default function toCase(input: string, target: TargetCaseType): string;
//# sourceMappingURL=to-case.d.ts.map