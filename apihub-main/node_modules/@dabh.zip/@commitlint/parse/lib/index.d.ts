import { Commit, Parser, ParserOptions } from '@commitlint/types';
export declare function parse(message: string, parser?: Parser, parserOpts?: ParserOptions): Promise<Commit>;
export default parse;
//# sourceMappingURL=index.d.ts.map