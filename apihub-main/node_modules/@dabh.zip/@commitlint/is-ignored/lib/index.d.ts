export * from './is-ignored';
export { default } from './is-ignored';
//# sourceMappingURL=index.d.ts.map