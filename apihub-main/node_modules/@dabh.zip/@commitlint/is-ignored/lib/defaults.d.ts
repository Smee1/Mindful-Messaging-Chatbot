import { Matcher } from '@commitlint/types';
export declare const wildcards: Matcher[];
//# sourceMappingURL=defaults.d.ts.map