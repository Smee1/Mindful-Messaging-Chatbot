import { IsIgnoredOptions } from '@commitlint/types';
export default function isIgnored(commit?: string, opts?: IsIgnoredOptions): boolean;
//# sourceMappingURL=is-ignored.d.ts.map