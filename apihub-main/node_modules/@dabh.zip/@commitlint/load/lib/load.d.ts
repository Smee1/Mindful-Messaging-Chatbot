import { LoadOptions, QualifiedConfig, UserConfig } from '@commitlint/types';
export default function load(seed?: UserConfig, options?: LoadOptions): Promise<QualifiedConfig>;
//# sourceMappingURL=load.d.ts.map