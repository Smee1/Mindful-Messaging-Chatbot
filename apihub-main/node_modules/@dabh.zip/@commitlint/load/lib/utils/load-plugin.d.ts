import { PluginRecords } from '@commitlint/types';
export default function loadPlugin(plugins: PluginRecords, pluginName: string, debug?: boolean): PluginRecords;
//# sourceMappingURL=load-plugin.d.ts.map