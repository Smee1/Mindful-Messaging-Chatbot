'use strict';

var argv = require('../')(process.argv.slice(2));
console.log(argv);
