Specs:

   - [ ] drop test "should"s
   - [ ] "sees session counter incremented"
   - [ ] tests to jasmine / drop `this`

- - - - -

supertest replacement

    describe('get', '/foo/bar')
      .then(expect('it returns a 200', ...))
      .then(expect('it returns a JSON object'))
      .end(done)

