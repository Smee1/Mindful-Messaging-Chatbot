#!/bin/bash

set -e

COMMIT=$(git rev-parse HEAD)
LAST_TAG=$(git describe --abbrev=0 --tags)
CHANGES=$(git log "${LAST_TAG}...${COMMIT}" --no-merges --pretty=format:"  * (%an) %s")

case in $1
  CHANGELOG
esac
