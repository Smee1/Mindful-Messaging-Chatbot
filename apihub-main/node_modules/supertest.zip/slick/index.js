/*
slick
*/"use strict"

module.exports = "document" in global ? require("./finder") : { parse: require("./parser") }
