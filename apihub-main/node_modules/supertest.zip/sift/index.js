const lib = require("./lib");

module.exports = lib.default;
Object.assign(module.exports, lib);
