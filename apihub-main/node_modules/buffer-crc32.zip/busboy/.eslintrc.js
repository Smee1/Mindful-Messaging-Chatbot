'use strict';

module.exports = {
  extends: '@mscdex/eslint-config',
};
