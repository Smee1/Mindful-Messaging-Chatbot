import test from 'ava'

test('base test', (t) => {
  t.is(true, true)
})
