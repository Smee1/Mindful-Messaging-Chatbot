export class RomanNumerals {
  static numerals = [
    'M',
    'CM',
    'D',
    'CD',
    'C',
    'XC',
    'L',
    'XL',
    'X',
    'IX',
    'V',
    'IV',
    'I',
  ]
  static numbers = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]

  static toRoman(num) {
    return this.numerals.reduce(
      ([outcome, remainder], numeral, index) => {
        while (remainder / this.numbers[index] >= 1) {
          outcome += numeral
          remainder -= this.numbers[index]
        }
        return [outcome, remainder]
      },
      ['', num],
    )[0]
  }

  static fromRoman(str) {
    return this.numbers.reduce(
      (out, number, index) => {
        while (out[1].indexOf(this.numerals[index]) === 0) {
          out[0] += number
          out[1] = out[1].replace(this.numerals[index], '')
        }
        return out
      },
      [0, str],
    )[0]
  }
}
