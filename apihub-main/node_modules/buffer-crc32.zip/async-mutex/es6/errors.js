export var E_TIMEOUT = new Error('timeout while waiting for mutex to become available');
export var E_ALREADY_LOCKED = new Error('mutex already locked');
export var E_CANCELED = new Error('request for lock canceled');
