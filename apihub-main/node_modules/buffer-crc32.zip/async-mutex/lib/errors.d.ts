export declare const E_TIMEOUT: Error;
export declare const E_ALREADY_LOCKED: Error;
export declare const E_CANCELED: Error;
