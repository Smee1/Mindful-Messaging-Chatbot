import { RandomGenerator } from '../../generator/RandomGenerator.js';
import { ArrayInt } from './ArrayInt.js';
export declare function unsafeUniformArrayIntDistributionInternal(out: ArrayInt['data'], rangeSize: ArrayInt['data'], rng: RandomGenerator): ArrayInt['data'];
