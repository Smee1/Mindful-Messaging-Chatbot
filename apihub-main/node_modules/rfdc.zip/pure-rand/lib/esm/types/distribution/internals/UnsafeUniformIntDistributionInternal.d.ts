import { RandomGenerator } from '../../generator/RandomGenerator.js';
export declare function unsafeUniformIntDistributionInternal(rangeSize: number, rng: RandomGenerator): number;
