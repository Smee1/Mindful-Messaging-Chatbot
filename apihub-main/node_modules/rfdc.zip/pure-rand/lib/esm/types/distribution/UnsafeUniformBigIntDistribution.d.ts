import { RandomGenerator } from '../generator/RandomGenerator.js';
export declare function unsafeUniformBigIntDistribution(from: bigint, to: bigint, rng: RandomGenerator): bigint;
