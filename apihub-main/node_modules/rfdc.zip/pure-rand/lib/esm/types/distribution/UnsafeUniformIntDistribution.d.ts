import { RandomGenerator } from '../generator/RandomGenerator.js';
export declare function unsafeUniformIntDistribution(from: number, to: number, rng: RandomGenerator): number;
