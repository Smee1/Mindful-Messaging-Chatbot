import * as prand from './pure-rand-default.js';
export default prand;
export * from './pure-rand-default.js';
