import { RandomGenerator } from './RandomGenerator.js';
export declare const xorshift128plus: (seed: number) => RandomGenerator;
