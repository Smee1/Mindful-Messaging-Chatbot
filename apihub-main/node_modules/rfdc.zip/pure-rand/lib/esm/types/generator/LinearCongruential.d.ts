import { RandomGenerator } from './RandomGenerator.js';
export declare const congruential32: (seed: number) => RandomGenerator;
