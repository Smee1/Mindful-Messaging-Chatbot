import { RandomGenerator } from './RandomGenerator.js';
export default function (seed: number): RandomGenerator;
