import { RandomGenerator } from './RandomGenerator.js';
export declare const xoroshiro128plus: (seed: number) => RandomGenerator;
