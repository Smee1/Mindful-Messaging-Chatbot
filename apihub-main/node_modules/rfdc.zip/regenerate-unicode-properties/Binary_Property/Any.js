const set = require('regenerate')();
set.addRange(0x0, 0x10FFFF);
exports.characters = set;
