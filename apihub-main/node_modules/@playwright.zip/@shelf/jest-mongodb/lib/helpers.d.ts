export declare function getMongodbMemoryOptions(): any;
export declare function getMongoURLEnvName(): any;
export declare function shouldUseSharedDBForAllJestWorkers(): any;
