export declare function install(dir?: string): void;
export declare function set(file: string, cmd: string): void;
export declare function add(file: string, cmd: string): void;
export declare function uninstall(): void;
