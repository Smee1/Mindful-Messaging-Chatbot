export default function (len?: number): () => string;
