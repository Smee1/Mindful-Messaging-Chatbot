# CHANGELOG

### 1.3.0

- [#4] Add `SPLAT` symbol.
- [#3] Add linting & TravisCI.

### 1.2.0

- [#2] Move configs from `winston.config.{npm,syslog,npm}` into `triple-beam`. 

### 1.1.0

- Expose a `MESSAGE` Symbol, nothing more.

### 1.0.1

- Use `Symbol.for` because that is how they work apparently.

### 1.0.0

- Initial version. Defines a `LEVEL` Symbol, nothing more. 
