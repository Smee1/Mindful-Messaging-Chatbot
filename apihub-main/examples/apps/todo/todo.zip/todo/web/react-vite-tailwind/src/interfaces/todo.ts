export interface TodoInterface {
  title: string;
  description: string;
  isComplete: boolean;
  createdAt: string;
  updatedAt: string;
  _id: string;
}
