import ManageAccountPage from "../presentation/ManageAccountPage";


const ManageAccountPageContainer = () => {
    return (
        <ManageAccountPage />
    )
}

export default ManageAccountPageContainer;