import Footer from "../presentation/Footer"


const FooterContainer = () => {
    return (
        <Footer />
    )
}

export default FooterContainer;