// Re-exporter for Node.js < 12.16.0
module.exports = require('./dist/util.js')
