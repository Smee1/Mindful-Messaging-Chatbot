import {
  require_react
} from "./chunk-QV6VW2LK.js";
import "./chunk-HM4MQYWN.js";
export default require_react();
//# sourceMappingURL=react.js.map
