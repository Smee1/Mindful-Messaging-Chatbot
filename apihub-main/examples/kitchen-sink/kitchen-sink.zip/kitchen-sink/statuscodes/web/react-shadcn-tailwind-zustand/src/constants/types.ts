
export interface MappingType {
  [key: string]: string;
}
